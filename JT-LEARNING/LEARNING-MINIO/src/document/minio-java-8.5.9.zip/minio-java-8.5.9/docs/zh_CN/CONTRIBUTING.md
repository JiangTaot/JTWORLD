# 贡献者指南
* Fork minio-java.
* 创建你的分支 (`$ git checkout -b my-new-feature`)。
* 敲代码，敲代码...
* Commit你的修改(`$ git commit -am 'Add some feature'`)。
* 构建测试包 (`$ ./gradlew build`)。
* 功能测试 (`$ ./gradlew runFunctionalTest`)。
* Push到你的分支 (`$ git push origin my-new-feature`)。
* 创建一个Pull Request。
